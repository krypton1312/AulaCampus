﻿$frutas = @("Manzana", "Banana", "Naranja", "Fresa", "Mango")

foreach ($fruta in $frutas) {
    Write-Host $fruta -ForegroundColor White -BackgroundColor Black 
}
