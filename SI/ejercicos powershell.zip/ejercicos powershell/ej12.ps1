﻿$resultado = 0
for ($i = 1; $i -le 100; $i++)
{ 
    $resultado +=$i
}
Write-Host $resultado -ForegroundColor Green