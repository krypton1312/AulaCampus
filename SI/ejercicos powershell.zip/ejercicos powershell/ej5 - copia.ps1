﻿$name = Read-Host "Introduce el nombre de usario existente"
Disable-LocalUser -Name $name