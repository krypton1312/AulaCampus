package act3t3;

public class Rectangulo {
	public double calculaPerimetro(int lado1, int lado2) {
		return (2*lado1)+(2*lado2);
	}
	public double calculaArea(int lado1, int lado2) {
		return lado1*lado2;
	}
	
}
