package act1t3;
public class Act1t3 {
    public static void main(String[] args) {
        CalculaImportes c = new CalculaImportes();
        System.out.println(c.calculaPrecioFinal(100, 21, 10));
    }

}
