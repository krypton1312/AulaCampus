package act7t4;
public class Act7T4 {
    public static void main(String[] args) {

    }

}
