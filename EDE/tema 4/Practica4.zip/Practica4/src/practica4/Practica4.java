package practica4;
public class Practica4 {
    public static void main(String[] args) {

    }

}
