package ejercicio4;
import objetos.Viaje;
public class Ejercicio4 {
    public static void main(String[] args) {
        
    }
}
