package act26t5;

public abstract class Sorteo {
    public abstract void lanzar();
}
