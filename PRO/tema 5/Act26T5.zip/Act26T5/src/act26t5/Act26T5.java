package act26t5;
public class Act26T5 {
   public static void main(String[] args) {
        Sorteo dado = new Dado();
        dado.lanzar();

        Sorteo moneda = new Moneda();
        moneda.lanzar();
    }
}
