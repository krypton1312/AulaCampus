package empleadoej21;
public class EmpleadoEj21 {
    public static void main(String[] args) {
        Empleado emp = new Empleado("1", "Luis", "Sanz Solis", 1250 ,1 , true, 2);
        System.out.println(emp);
    }

}
