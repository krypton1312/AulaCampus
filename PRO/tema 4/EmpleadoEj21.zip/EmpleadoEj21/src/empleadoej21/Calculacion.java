package empleadoej21;

public interface Calculacion {
    double calculaRetencion();
    double calculaPlus();
}
