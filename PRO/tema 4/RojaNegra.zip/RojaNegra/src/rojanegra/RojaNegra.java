package rojanegra;
import probabilidad.Probabilidad;
public class RojaNegra {
    public static void main(String[] args) {
        Probabilidad try1 = new Probabilidad();
        System.out.println(try1.azar());
    }
}
