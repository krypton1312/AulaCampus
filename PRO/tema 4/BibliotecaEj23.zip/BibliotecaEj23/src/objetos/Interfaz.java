package objetos;

public interface Interfaz {
    public boolean prestado = false;
    public void prestar();
    public void devolver();
}
